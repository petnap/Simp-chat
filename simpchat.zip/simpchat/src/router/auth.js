import Auth from '@/components/Auth'

export default {
  path: '/',
  name: 'Auth',
  component: Auth
}
