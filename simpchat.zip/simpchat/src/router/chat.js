import Chat from '@/components/Chat'

export default {
  path: '/',
  name: 'Chat',
  component: Chat
}
